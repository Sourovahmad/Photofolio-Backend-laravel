import React from 'react';

const Home = () => {
    return (
        <div>
            <h1> Iam Home</h1>
        </div>
    );
};

export default Home;
