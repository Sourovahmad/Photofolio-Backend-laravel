import React from 'react';
import { useParams } from 'react-router';

const Items = () => {
    return (
        <div>
            <h1> hello iam tems</h1>
        </div>
    );
};

export default Items;
