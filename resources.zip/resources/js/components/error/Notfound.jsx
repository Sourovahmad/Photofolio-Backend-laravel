import React from 'react';

const Notfound = () => {
    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="text-center">
                        <h4> OPPS!  The Url Not Foound</h4>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Notfound;
